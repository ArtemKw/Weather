package com.pinescript.weatherrr2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = findViewById(R.id.textView);
    }

    public void onClick(View view) {

        WeatherApi weatherApi = WeatherApi.retrofit.create(WeatherApi.class);

        Call<WeatherFeo> call = weatherApi.getWeather();

        call.enqueue(new Callback<WeatherFeo>() {
            @Override
            public void onResponse(Call<WeatherFeo> call, Response<WeatherFeo> response) {

                if (response.isSuccessful()) {

                    String weatherFeo = response.body().toString();


                    // выводим данные всего списка

                    mTextView.setText(weatherFeo);

                } else {
                    ResponseBody errorBody = response.errorBody();
                    try {
                        mTextView.setText(errorBody.string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherFeo> call, Throwable throwable) {
                mTextView.setText(throwable.getLocalizedMessage());
            }
        });
    }
}