package com.pinescript.weatherrr2;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public interface WeatherApi {
    @GET("current.json?key=738d6a75807c480fa69170707210111&q=Feodosia&aqi=no")
    Call<WeatherFeo> getWeather();
    Retrofit retrofit= new Retrofit.Builder()
            .baseUrl("https://api.weatherapi.com/v1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();

}
