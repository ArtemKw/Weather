package com.pinescript.weatherrr2;

public class WeatherFeo
{
    private Current current;

    private Location location;

    public Current getCurrent ()
    {
        return current;
    }

    public void setCurrent (Current current)
    {
        this.current = current;
    }

    public Location getLocation ()
    {
        return location;
    }

    public void setLocation (Location location)
    {
        this.location = location;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [current = "+current+", location = "+location+"]";
    }
}
